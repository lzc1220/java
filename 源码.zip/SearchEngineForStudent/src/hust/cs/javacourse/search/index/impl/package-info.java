/**
 * 对hust.cs.javacourse.search.index包里定义的抽象类和接口的具体实现放在这个包里。impl(implementation)
 */
package hust.cs.javacourse.search.index.impl;